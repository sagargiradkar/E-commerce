
public class IncDec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		//int a=5;
		//System.out.println(a);
		//a++;
		//++a;
		//System.out.println(a);
		
		
		int a=5;
		int b;
		b=a++ + --a - a-- - a++;
		System.out.println(a);
		System.out.println(b);
		

	}

}
