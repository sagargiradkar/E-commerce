



public class LaunchStaticBlock {

	static int a;
	
	static {
		a=10;
		System.out.println("Static block1");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main method");

	}

}
