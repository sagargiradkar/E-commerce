package in.ineuron.bean;

//Dependent Object 
public class Account {

	String accNo;
	String accName;
	String accType;

	public Account(String accNo, String accName, String accType) {
		super();
		this.accNo = accNo;
		this.accName = accName;
		this.accType = accType;
	}

}
