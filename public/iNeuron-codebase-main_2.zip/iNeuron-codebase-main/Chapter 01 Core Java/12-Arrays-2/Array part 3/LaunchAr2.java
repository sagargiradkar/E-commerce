
public class LaunchAr2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[][] a;
		int [][]b;
		int c[][];
		int []ar[];
		
		int[] ab,cd;
		ab=new int[4];
		cd=new int[5];
		
		int m,n,o;
		m=10;
		n=20;
		o=40;
		
		int [][] xx,yy;//xx=2D yy=2d
		int [] []x[],y;// x=3d y=2d
		
		int[][] xy[],yz;//xy 3d , yz 2d
		
		int [][]aa, bb[]; // aa= 2d bb=3d
		
		//int []arrr, []brr; CE
		int []aaa, bbb[][];
		
		//Demo d=new Demo();

	}

}
