
public class LaunchARRR {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int[] a=new int[4];
		
		System.out.println(a.getClass().getName());
		
		int[][] ar=new int[4][2];
		
		System.out.println(ar.getClass().getName());
		
		//Demo d=new Demo();

	}

}
