
public class Launch1 
{

	public static void main(String[] args) 
	{
		int a=4;
		int b=2;
		int res=a%b;
		System.out.println(res);

	}

}
