
public class Launch2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * int a=10; int b=20;
		 * 
		 * System.out.println(a>b); System.out.println(a<b); System.out.println(a==b);
		 */
		/*
		 * int abc=5; abc=10;
		 * 
		 * 
		 * 
		 * int a,b,c,d;
		 * 
		 * a=b=c=d=10+5;
		 * 
		 * System.out.println(a + " "+b + " " +c+" "+d);
		 */
		
		
		int a=2;
		
		a+=20;
		System.out.println(a);
		a-=20;
		System.out.println(a);
		a*=20;
		System.out.println(a);
		a/=20;
		System.out.println(a);
		a%=20;
		System.out.println(a);
	
		

	}

}
